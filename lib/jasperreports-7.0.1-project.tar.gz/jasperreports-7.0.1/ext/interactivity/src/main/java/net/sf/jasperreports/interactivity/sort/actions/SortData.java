/*
 * JasperReports - Free Java Reporting Library.
 * Copyright (C) 2001 - 2023 Cloud Software Group, Inc. All rights reserved.
 * http://www.jaspersoft.com
 *
 * Unless you have purchased a commercial license agreement from Jaspersoft,
 * the following license terms apply:
 *
 * This program is part of JasperReports.
 *
 * JasperReports is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * JasperReports is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with JasperReports. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.jasperreports.interactivity.sort.actions;

import net.sf.jasperreports.engine.JRConstants;
import net.sf.jasperreports.interactivity.headertoolbar.actions.BaseColumnData;



/**
 * @author Narcis Marcu (narcism@users.sourceforge.net)
 */
public class SortData extends BaseColumnData {
	
	private static final long serialVersionUID = JRConstants.SERIAL_VERSION_UID;
	
	private String sortColumnName;
	private String sortColumnType;
	private String sortOrder;
	
	public SortData() {
	}
	
	public SortData(String tableUuid, String sortColumnName, String sortColumnType, String sortOrder) {
		super(tableUuid);
		this.sortColumnName = sortColumnName;
		this.sortColumnType = sortColumnType;
		this.sortOrder = sortOrder;
	}

	public String getSortColumnName() {
		return sortColumnName;
	}

	public void setSortColumnName(String sortColumnName) {
		this.sortColumnName = sortColumnName;
	}

	public String getSortColumnType() {
		return sortColumnType;
	}

	public void setSortColumnType(String sortColumnType) {
		this.sortColumnType = sortColumnType;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

}
